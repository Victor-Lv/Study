#include "stdlib.h" //support "NULL"

template <typename Node_entry>
struct Node
{
	Node_entry value;
	Node<Node_entry> *next;
	Node();
	Node(Node_entry value, Node<Node_entry> *next = NULL);
};
